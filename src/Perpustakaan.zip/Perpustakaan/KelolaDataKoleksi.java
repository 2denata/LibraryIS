package Perpustakaan;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.io.*;

public class KelolaDataKoleksi extends javax.swing.JDialog {

    Koleksi koleksi;
    DefaultTableModel modelTabel;
    DAOPerpustakaan list = new DAOPerpustakaan();

    public KelolaDataKoleksi(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        awal();
    }

    private void awal() {
        textFieldFormat.setVisible(false);
        textFieldHalaman.setVisible(false);
        textFieldISBN.setVisible(false);
        labelFormat.setVisible(false);
        labelHalaman.setVisible(false);
        labelISBN.setVisible(false);
        textFieldVolume.setVisible(false);
        textFieldSeri.setVisible(false);
        textFieldISSN.setVisible(false);
        textFieldHalaman.setVisible(false);
        labelVolume.setVisible(false);
        labelSeri.setVisible(false);
        labelISSN.setVisible(false);
        labelHalaman.setVisible(false);
        buttonTambah.setEnabled(false);
    }

    private void reset() {
        textFieldFormat.setText("");
        textFieldHalaman.setText("");
        textFieldIDKoleksi.setText("");
        textFieldISBN.setText("");
        textFieldISSN.setText("");
        textFieldJudul.setText("");
        textFieldPenerbit.setText("");
        textFieldSeri.setText("");
        textFieldVolume.setText("");
        textFieldTahunTerbit.setText("");
        checkBoxStatusPinjam.setSelected(false);
        radioBuku.setSelected(false);
        radioMajalah.setSelected(false);
        radioBuku.setSelected(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        radioMajalah = new javax.swing.JRadioButton();
        radioDisk = new javax.swing.JRadioButton();
        radioBuku = new javax.swing.JRadioButton();
        labelPenerbit = new javax.swing.JLabel();
        textFieldIDKoleksi = new javax.swing.JTextField();
        labelIDKoleksi = new javax.swing.JLabel();
        textFieldJudul = new javax.swing.JTextField();
        labelJudul = new javax.swing.JLabel();
        textFieldPenerbit = new javax.swing.JTextField();
        labelStatusPinjam = new javax.swing.JLabel();
        checkBoxStatusPinjam = new javax.swing.JCheckBox();
        labelVolume = new javax.swing.JLabel();
        textFieldVolume = new javax.swing.JTextField();
        labelSeri = new javax.swing.JLabel();
        textFieldSeri = new javax.swing.JTextField();
        buttonTambah = new javax.swing.JButton();
        buttonHapus = new javax.swing.JButton();
        buttonReset = new javax.swing.JButton();
        buttonKeluar = new javax.swing.JButton();
        textFieldISSN = new javax.swing.JTextField();
        labelISSN = new javax.swing.JLabel();
        labelISBN = new javax.swing.JLabel();
        textFieldISBN = new javax.swing.JTextField();
        textFieldFormat = new javax.swing.JTextField();
        labelFormat = new javax.swing.JLabel();
        textFieldHalaman = new javax.swing.JTextField();
        labelHalaman = new javax.swing.JLabel();
        labelStatusPinjam1 = new javax.swing.JLabel();
        textFieldTahunTerbit = new javax.swing.JTextField();
        checkBoxVerif = new javax.swing.JCheckBox();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabelKoleksi = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Kelola Data Koleksi");

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        buttonGroup1.add(radioMajalah);
        radioMajalah.setText("Majalah");
        radioMajalah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                radioMajalahActionPerformed(evt);
            }
        });

        buttonGroup1.add(radioDisk);
        radioDisk.setText("Disk");
        radioDisk.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                radioDiskActionPerformed(evt);
            }
        });

        buttonGroup1.add(radioBuku);
        radioBuku.setText("Buku");
        radioBuku.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                radioBukuActionPerformed(evt);
            }
        });

        labelPenerbit.setText("Penerbit");

        textFieldIDKoleksi.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                textFieldIDKoleksiFocusLost(evt);
            }
        });

        labelIDKoleksi.setText("id Koleksi");

        labelJudul.setText("Judul");

        labelStatusPinjam.setText("Status Pinjam");

        checkBoxStatusPinjam.setText("Dipinjam");

        labelVolume.setText("Volume");

        textFieldVolume.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                textFieldVolumeFocusLost(evt);
            }
        });

        labelSeri.setText("Seri");

        textFieldSeri.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                textFieldSeriFocusLost(evt);
            }
        });

        buttonTambah.setText("Tambah");
        buttonTambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonTambahActionPerformed(evt);
            }
        });

        buttonHapus.setText("Hapus");
        buttonHapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonHapusActionPerformed(evt);
            }
        });

        buttonReset.setText("Reset");
        buttonReset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonResetActionPerformed(evt);
            }
        });

        buttonKeluar.setText("Keluar");
        buttonKeluar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonKeluarActionPerformed(evt);
            }
        });

        labelISSN.setText("ISSN");

        labelISBN.setText("ISBN");

        textFieldFormat.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                textFieldFormatFocusLost(evt);
            }
        });

        labelFormat.setText("Format");

        textFieldHalaman.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                textFieldHalamanFocusLost(evt);
            }
        });

        labelHalaman.setText("Halaman");

        labelStatusPinjam1.setText("Tahun Terbit");

        textFieldTahunTerbit.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                textFieldTahunTerbitFocusLost(evt);
            }
        });

        checkBoxVerif.setText("Verifikasi");
        checkBoxVerif.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkBoxVerifActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(labelIDKoleksi)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(textFieldIDKoleksi, javax.swing.GroupLayout.PREFERRED_SIZE, 498, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(labelJudul)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(textFieldJudul, javax.swing.GroupLayout.PREFERRED_SIZE, 498, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(labelStatusPinjam)
                                            .addComponent(labelVolume)
                                            .addComponent(labelSeri)
                                            .addComponent(labelISSN)
                                            .addComponent(labelISBN)
                                            .addComponent(labelFormat)
                                            .addComponent(labelStatusPinjam1))
                                        .addGap(86, 86, 86))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                        .addComponent(labelPenerbit)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(checkBoxStatusPinjam)
                                    .addComponent(textFieldPenerbit, javax.swing.GroupLayout.PREFERRED_SIZE, 498, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(textFieldVolume, javax.swing.GroupLayout.PREFERRED_SIZE, 498, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(textFieldSeri, javax.swing.GroupLayout.PREFERRED_SIZE, 498, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(textFieldISSN, javax.swing.GroupLayout.PREFERRED_SIZE, 498, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(textFieldISBN, javax.swing.GroupLayout.PREFERRED_SIZE, 498, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(textFieldFormat, javax.swing.GroupLayout.PREFERRED_SIZE, 498, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(textFieldHalaman, javax.swing.GroupLayout.PREFERRED_SIZE, 498, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(textFieldTahunTerbit, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(labelHalaman)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap(249, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(checkBoxVerif)
                .addGap(85, 85, 85))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(154, 154, 154)
                    .addComponent(radioMajalah)
                    .addGap(126, 126, 126)
                    .addComponent(radioDisk)
                    .addGap(125, 125, 125)
                    .addComponent(radioBuku)
                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 115, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(buttonTambah, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(buttonHapus, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(buttonReset, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(buttonKeluar, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 223, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addContainerGap()))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(checkBoxVerif)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textFieldIDKoleksi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labelIDKoleksi))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textFieldJudul, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labelJudul))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textFieldPenerbit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labelPenerbit))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(checkBoxStatusPinjam)
                    .addComponent(labelStatusPinjam))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelStatusPinjam1)
                    .addComponent(textFieldTahunTerbit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textFieldVolume, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labelVolume))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textFieldSeri, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labelSeri))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textFieldISSN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labelISSN))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(textFieldISBN, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labelISBN))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(labelFormat)
                    .addComponent(textFieldFormat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(labelHalaman)
                    .addComponent(textFieldHalaman, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addContainerGap()
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(radioMajalah)
                        .addComponent(radioDisk)
                        .addComponent(radioBuku))
                    .addGap(18, 18, 18)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addComponent(buttonTambah, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(44, 44, 44)
                            .addComponent(buttonHapus, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGap(162, 162, 162)
                            .addComponent(buttonReset, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGap(27, 27, 27)
                    .addComponent(buttonKeluar, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(51, Short.MAX_VALUE)))
        );

        jLabel1.setText("Form Data Koleksi");

        tabelKoleksi.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID Koleksi", "Judul", "Penerbit", "Status Pinjam", "ISBN/ISSN"
            }
        ));
        tabelKoleksi.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tabelKoleksiMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tabelKoleksi);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jScrollPane1))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void radioMajalahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_radioMajalahActionPerformed
        //show
        textFieldVolume.setVisible(true);
        textFieldSeri.setVisible(true);
        textFieldISSN.setVisible(true);
        labelVolume.setVisible(true);
        labelSeri.setVisible(true);
        labelISSN.setVisible(true);

        //hide
        textFieldFormat.setVisible(false);
        textFieldHalaman.setVisible(false);
        textFieldISBN.setVisible(false);
        labelFormat.setVisible(false);
        labelHalaman.setVisible(false);
        labelISBN.setVisible(false);
    }//GEN-LAST:event_radioMajalahActionPerformed

    private void radioDiskActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_radioDiskActionPerformed
        textFieldFormat.setVisible(true);
        labelFormat.setVisible(true);
        textFieldISBN.setVisible(true);
        labelISBN.setVisible(true);

        textFieldVolume.setVisible(false);
        textFieldSeri.setVisible(false);
        textFieldISSN.setVisible(false);
        textFieldHalaman.setVisible(false);
        labelVolume.setVisible(false);
        labelSeri.setVisible(false);
        labelISSN.setVisible(false);
        labelHalaman.setVisible(false);
    }//GEN-LAST:event_radioDiskActionPerformed


    private void buttonTambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonTambahActionPerformed
        try {
            if (radioMajalah.isSelected()) {
                String id, judul, penerbit, issn;
                int volume, seri;
                boolean checkBox;
                id = textFieldIDKoleksi.getText();
                judul = textFieldJudul.getText();
                penerbit = textFieldPenerbit.getText();
                issn = textFieldISSN.getText();
                volume = Integer.parseInt(textFieldVolume.getText());
                seri = Integer.parseInt(textFieldSeri.getText());
                checkBox = checkBoxStatusPinjam.isSelected();
                if (id.isEmpty() || judul.isEmpty() || penerbit.isEmpty() || issn.isEmpty()
                        || textFieldVolume.getText().isEmpty() || textFieldSeri.getText().isEmpty()) {
                    throw new Exception();
                }
                koleksi = new Majalah(volume, seri, issn, id, judul, penerbit, checkBox);

            } else if (radioDisk.isSelected()) {
                String id, judul, penerbit, f, ISBN;
                boolean checkBox;
                f = textFieldFormat.getText();
                id = textFieldIDKoleksi.getText();
                judul = textFieldJudul.getText();
                penerbit = textFieldPenerbit.getText();
                ISBN = textFieldISBN.getText();
                checkBox = checkBoxStatusPinjam.isSelected();
                if (id.isEmpty() || judul.isEmpty() || penerbit.isEmpty() || ISBN.isEmpty() || f.isEmpty()) {
                    throw new Exception();
                }
                if (f.equals("Audio") || f.equals("Video") || f.equals("Document")) {
                    koleksi = new Disk(f, ISBN, id, judul, penerbit, checkBox);

                } else {
                    JOptionPane.showMessageDialog(this, "Format Disk berupa 'Audio', 'Video', dan 'Document'");
                    textFieldFormat.setText("");
                }

            } else if (radioBuku.isSelected()) {
                String id, judul, penerbit, ISBN, hal;
                int halaman;
                boolean checkBox;
                id = textFieldIDKoleksi.getText();
                judul = textFieldJudul.getText();
                penerbit = textFieldPenerbit.getText();
                ISBN = textFieldISBN.getText();
                hal = textFieldHalaman.getText();
                halaman = Integer.parseInt(textFieldHalaman.getText());
                checkBox = checkBoxStatusPinjam.isSelected();
                if (id.isEmpty() || judul.isEmpty() || penerbit.isEmpty() || ISBN.isEmpty() || hal.isEmpty()) {
                    throw new Exception();
                }

                koleksi = new Buku(halaman, ISBN, id, judul, penerbit, checkBox);

            }

            list.getKoleksi().add(koleksi);
            tampilData();
            reset();
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Mohon masukkan halaman, volume, atau seri dengan angka");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Mohon isi semua data yang tersedia");
        }
    }//GEN-LAST:event_buttonTambahActionPerformed

    private void tampilData() {
        String[] columnNames = {"ID Koleksi", "Judul", "Penerbit", "Status Pinjam", "ISBN/ISSN"};
        Object[][] objData = new Object[list.getKoleksi().size()][columnNames.length];
        int i = 0;

        for (Koleksi k : list.getKoleksi()) {
            Object[] teks = {k.getIdKoleksi(), k.getJudul(), k.getPenerbit(), k.isStatus_pinjam(), k.getIS()};
            objData[i] = teks;
            i++;
        }
        modelTabel = new DefaultTableModel(objData, columnNames) {
            @Override
            public boolean isCellEditable(int rowIndex, int colIndex) {
                return false;

            }
        };
        tabelKoleksi.setModel(modelTabel);
        tabelKoleksi.setAutoCreateRowSorter(true);
        tabelKoleksi.repaint();
    }


    private void radioBukuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_radioBukuActionPerformed
        textFieldHalaman.setVisible(true);
        textFieldISBN.setVisible(true);
        labelHalaman.setVisible(true);
        labelISBN.setVisible(true);

        textFieldFormat.setVisible(false);
        textFieldISSN.setVisible(false);
        textFieldVolume.setVisible(false);
        textFieldSeri.setVisible(false);
        labelFormat.setVisible(false);
        labelISSN.setVisible(false);
        labelVolume.setVisible(false);
        labelSeri.setVisible(false);

    }//GEN-LAST:event_radioBukuActionPerformed

    private void buttonResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonResetActionPerformed
        reset();
    }//GEN-LAST:event_buttonResetActionPerformed

    private void buttonKeluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonKeluarActionPerformed
        try {
            buatFile();
        } catch (IOException ex) {
        }
        this.dispose();
    }//GEN-LAST:event_buttonKeluarActionPerformed

    private void buatFile() throws FileNotFoundException, IOException {
        //Ambil data dari file eksternal
        File outFile = new File("C:\\Users\\LENOVO\\Desktop\\Koleksi.dat");
        FileOutputStream outFileStream = new FileOutputStream(outFile);
        ObjectOutputStream outObjectStream = new ObjectOutputStream(outFileStream);

        //Buat objek koleksi, copy objek dari file eksternal
        Koleksi[] temp = new Koleksi[list.getKoleksi().size()];
        for (int i = 0; i < list.getKoleksi().size(); i++) {
            temp[i] = list.getKoleksi().get(i);
        }

        //menuliskan data ke objek koleksi
        outObjectStream.writeObject(temp);

        //menutup stream
        outObjectStream.close();
    }

    private void buttonHapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonHapusActionPerformed
        int a = tabelKoleksi.getSelectedRow();
        if (a == -1) {
        } else {
            list.getKoleksi().remove(a);
            tampilData();
        }
    }//GEN-LAST:event_buttonHapusActionPerformed

    private void textFieldIDKoleksiFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_textFieldIDKoleksiFocusLost
        String id = textFieldIDKoleksi.getText();
        if (id.charAt(0) == 'D' || id.charAt(0) == 'M' || id.charAt(0) == 'B') {
        } else {
            JOptionPane.showMessageDialog(this, "ID Koleksi harus diawali dengan D/M/B");
            textFieldIDKoleksi.setText("");
        }
    }//GEN-LAST:event_textFieldIDKoleksiFocusLost

    private void textFieldTahunTerbitFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_textFieldTahunTerbitFocusLost
        String pattern = "[0-9]*";
        String tahun = textFieldTahunTerbit.getText();
        if (tahun.matches(pattern) && tahun.length() == 4) {
        } else if (tahun.matches(pattern)) {
            JOptionPane.showMessageDialog(this, "Mohon memasukkan 4 angka tahun");
            textFieldTahunTerbit.setText("");
        } else if (tahun.length() == 4) {
            JOptionPane.showMessageDialog(this, "Mohon memasukkan angka untuk tahun!");
            textFieldTahunTerbit.setText("");
        } else {
            JOptionPane.showMessageDialog(this, "Mohon memasukkan format tahun yang benar!");
            textFieldTahunTerbit.setText("");
        }
    }//GEN-LAST:event_textFieldTahunTerbitFocusLost

    private void textFieldVolumeFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_textFieldVolumeFocusLost
        String pattern = "[0-9]*";
        String volume = textFieldVolume.getText();
        if (!(volume.matches(pattern))) {
            JOptionPane.showMessageDialog(this, "Volume berupa digit integer!");
            textFieldVolume.setText("");
        }
    }//GEN-LAST:event_textFieldVolumeFocusLost

    private void textFieldSeriFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_textFieldSeriFocusLost
        String pattern = "[0-9]*";
        String volume = textFieldSeri.getText();
        if (!(volume.matches(pattern))) {
            JOptionPane.showMessageDialog(this, "Seri berupa digit integer!");
            textFieldSeri.setText("");
        }
    }//GEN-LAST:event_textFieldSeriFocusLost

    private void textFieldHalamanFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_textFieldHalamanFocusLost
        String pattern = "[0-9]*";
        String volume = textFieldHalaman.getText();
        if (!(volume.matches(pattern))) {
            JOptionPane.showMessageDialog(this, "Halaman berupa digit integer!");
            textFieldHalaman.setText("");
        }
    }//GEN-LAST:event_textFieldHalamanFocusLost

    private void textFieldFormatFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_textFieldFormatFocusLost
        String f = textFieldFormat.getText();
        if (f.equals("Audio") || f.equals("Video") || f.equals("Document")) {
        } else {
            JOptionPane.showMessageDialog(this, "Format Disk berupa 'Audio', 'Video', dan 'Document'");
            textFieldFormat.setText("");
        }
    }//GEN-LAST:event_textFieldFormatFocusLost

    private void tabelKoleksiMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tabelKoleksiMouseClicked
        int selectedRow = tabelKoleksi.getSelectedRow();
        textFieldIDKoleksi.setText(modelTabel.getValueAt(selectedRow, 0).toString());
        textFieldJudul.setText(modelTabel.getValueAt(selectedRow, 1).toString());
        textFieldPenerbit.setText(modelTabel.getValueAt(selectedRow, 2).toString());
        textFieldISBN.setText(modelTabel.getValueAt(selectedRow, 4).toString());
        String temp = modelTabel.getValueAt(selectedRow, 3).toString();
        if (temp.equals("true")) {
            checkBoxStatusPinjam.setSelected(true);
        } else {
            checkBoxStatusPinjam.setSelected(false);
        }
    }//GEN-LAST:event_tabelKoleksiMouseClicked

    private void checkBoxVerifActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkBoxVerifActionPerformed
        if (checkBoxVerif.isSelected()) {
            buttonTambah.setEnabled(true);
        } else {
            buttonTambah.setEnabled(false);
        }
    }//GEN-LAST:event_checkBoxVerifActionPerformed

    public static void main(String args[]) {
        
        
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(KelolaDataKoleksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(KelolaDataKoleksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(KelolaDataKoleksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(KelolaDataKoleksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                KelolaDataKoleksi dialog = new KelolaDataKoleksi(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JButton buttonHapus;
    private javax.swing.JButton buttonKeluar;
    private javax.swing.JButton buttonReset;
    private javax.swing.JButton buttonTambah;
    private javax.swing.JCheckBox checkBoxStatusPinjam;
    private javax.swing.JCheckBox checkBoxVerif;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel labelFormat;
    private javax.swing.JLabel labelHalaman;
    private javax.swing.JLabel labelIDKoleksi;
    private javax.swing.JLabel labelISBN;
    private javax.swing.JLabel labelISSN;
    private javax.swing.JLabel labelJudul;
    private javax.swing.JLabel labelPenerbit;
    private javax.swing.JLabel labelSeri;
    private javax.swing.JLabel labelStatusPinjam;
    private javax.swing.JLabel labelStatusPinjam1;
    private javax.swing.JLabel labelVolume;
    private javax.swing.JRadioButton radioBuku;
    private javax.swing.JRadioButton radioDisk;
    private javax.swing.JRadioButton radioMajalah;
    private javax.swing.JTable tabelKoleksi;
    private javax.swing.JTextField textFieldFormat;
    private javax.swing.JTextField textFieldHalaman;
    private javax.swing.JTextField textFieldIDKoleksi;
    private javax.swing.JTextField textFieldISBN;
    private javax.swing.JTextField textFieldISSN;
    private javax.swing.JTextField textFieldJudul;
    private javax.swing.JTextField textFieldPenerbit;
    private javax.swing.JTextField textFieldSeri;
    private javax.swing.JTextField textFieldTahunTerbit;
    private javax.swing.JTextField textFieldVolume;
    // End of variables declaration//GEN-END:variables

}
