package Perpustakaan;

import java.awt.Color;
import java.io.*;
import java.time.LocalDate;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class KelolaDataTransaksiPeminjaman extends javax.swing.JDialog {

    DAOPerpustakaan list = new DAOPerpustakaan();
    private int generateID = (int) (Math.random()*1000);

    public KelolaDataTransaksiPeminjaman(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        setTFAwal();
    }

    private void setTFAwal() {
        tfJudul.setEditable(false);
        tfJudul.setBackground(Color.LIGHT_GRAY);
        tfPenerbit.setEditable(false);
        tfPenerbit.setBackground(Color.LIGHT_GRAY);
        tfSeri.setEditable(false);
        tfSeri.setBackground(Color.LIGHT_GRAY);
        tfVolume.setEditable(false);
        tfVolume.setBackground(Color.LIGHT_GRAY);
        tfIS.setEditable(false);
        tfIS.setBackground(Color.LIGHT_GRAY);
        tfStatus.setEditable(false);
        tfStatus.setBackground(Color.LIGHT_GRAY);
        tfNomor.setEditable(false);
        tfNomor.setBackground(Color.LIGHT_GRAY);
        tfNama.setEditable(false);
        tfNama.setBackground(Color.LIGHT_GRAY);
        tfAlamat.setEditable(false);
        tfAlamat.setBackground(Color.LIGHT_GRAY);
        tfPinjam.setEditable(false);
        tfPinjam.setBackground(Color.LIGHT_GRAY);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        labelNomor = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        tfIDPeminjam = new javax.swing.JTextField();
        tfNomor = new javax.swing.JTextField();
        tfNama = new javax.swing.JTextField();
        tfAlamat = new javax.swing.JTextField();
        tfPinjam = new javax.swing.JTextField();
        buttonCariPeminjam = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        labelVolume = new javax.swing.JLabel();
        labelSeri = new javax.swing.JLabel();
        tfIDKoleksi = new javax.swing.JTextField();
        tfJudul = new javax.swing.JTextField();
        tfPenerbit = new javax.swing.JTextField();
        tfStatus = new javax.swing.JTextField();
        tfIS = new javax.swing.JTextField();
        tfVolume = new javax.swing.JTextField();
        tfSeri = new javax.swing.JTextField();
        buttonTambahPesanan = new javax.swing.JButton();
        buttonCariKoleksi = new javax.swing.JButton();
        jLabel15 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        buttonTransaksi = new javax.swing.JButton();
        buttonBatal = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabelPesananKoleksi = new javax.swing.JTable();
        jLabel13 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tabelTransaksi = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Kelola Data Transaksi Peminjaman");

        jPanel1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel1.setText("Dafa Peminjam");

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        jLabel3.setText("ID");

        labelNomor.setText("Nomor");

        jLabel5.setText("Nama");

        jLabel6.setText("Alamat");

        jLabel7.setText("Pinjam");

        tfIDPeminjam.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfIDPeminjamActionPerformed(evt);
            }
        });

        buttonCariPeminjam.setText("Cari");
        buttonCariPeminjam.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonCariPeminjamActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(tfNama))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tfAlamat))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tfPinjam)
                        .addGap(6, 6, 6))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(labelNomor)
                            .addComponent(jLabel3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(tfIDPeminjam, javax.swing.GroupLayout.PREFERRED_SIZE, 281, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(buttonCariPeminjam, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addComponent(tfNomor, javax.swing.GroupLayout.DEFAULT_SIZE, 384, Short.MAX_VALUE))))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(tfIDPeminjam, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(buttonCariPeminjam))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(labelNomor)
                    .addComponent(tfNomor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(tfNama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(tfAlamat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(tfPinjam, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel2.setText("Data Koleksi");

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        jLabel8.setText("ID ");

        jLabel9.setText("Judul");

        jLabel10.setText("Penerbit");

        jLabel11.setText("Status");

        jLabel12.setText("ISSN/BN");

        labelVolume.setText("Volume");

        labelSeri.setText("Seri");

        tfIDKoleksi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfIDKoleksiActionPerformed(evt);
            }
        });

        tfJudul.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfJudulActionPerformed(evt);
            }
        });

        buttonTambahPesanan.setText("Tambah Pesanan");
        buttonTambahPesanan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonTambahPesananActionPerformed(evt);
            }
        });

        buttonCariKoleksi.setText("Cari");
        buttonCariKoleksi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonCariKoleksiActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(tfPenerbit))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8)
                            .addComponent(jLabel9))
                        .addGap(26, 26, 26)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(tfIDKoleksi, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(buttonCariKoleksi, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(tfJudul)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel12)
                            .addComponent(jLabel11))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tfStatus)
                            .addComponent(tfIS)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(labelVolume)
                            .addComponent(labelSeri))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(tfVolume, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(tfSeri, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(buttonTambahPesanan, javax.swing.GroupLayout.PREFERRED_SIZE, 177, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(tfIDKoleksi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(buttonCariKoleksi))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(tfJudul, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(tfPenerbit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(tfStatus, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(tfIS, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(labelVolume)
                            .addComponent(tfVolume, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(labelSeri)
                            .addComponent(tfSeri, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(buttonTambahPesanan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel15.setText("Trabsaksi Peminjaman");

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(""));

        buttonTransaksi.setText("Proses Peminjaman");
        buttonTransaksi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonTransaksiActionPerformed(evt);
            }
        });

        buttonBatal.setText("Batal");
        buttonBatal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonBatalActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(buttonTransaksi, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(buttonBatal)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(buttonTransaksi)
                    .addComponent(buttonBatal))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        tabelPesananKoleksi.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "Judul", "Penerbit", "ISBN/SN", "Status"
            }
        ));
        jScrollPane1.setViewportView(tabelPesananKoleksi);

        jLabel13.setText("Daftar Pesanan Koleksi");

        jLabel16.setText("Data Transaksi");

        tabelTransaksi.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID Transaksi", "Peminjam", "Alamat", "Tanggal Pinjam", "Jumlah Pinjam"
            }
        ));
        jScrollPane2.setViewportView(tabelTransaksi);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel1)
                                    .addComponent(jLabel15)
                                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jLabel13)
                            .addComponent(jLabel16))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(jScrollPane2))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel15)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(11, 11, 11)
                .addComponent(jLabel13)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel16)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tfIDPeminjamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfIDPeminjamActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfIDPeminjamActionPerformed

    private void buttonCariPeminjamActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonCariPeminjamActionPerformed
        try {
            File inFile = new File("C:\\Users\\LENOVO\\Desktop\\Peminjam.dat");
            FileInputStream inFileStream = new FileInputStream(inFile);
            ObjectInputStream inObjectStream = new ObjectInputStream(inFileStream);
            Peminjam[] peminjam;
            String inputan = tfIDPeminjam.getText();

            peminjam = (Peminjam[]) inObjectStream.readObject();
            String id, nama, nomor, alamat, maxPinjam;
            int i = 0;
            while (i < peminjam.length) {
                id = peminjam[i].getIdPeminjam();
                nama = peminjam[i].getNama();
                nomor = peminjam[i].getNomor();
                alamat = peminjam[i].getAlamat();
                maxPinjam = String.valueOf(peminjam[i].getMak_pinjam());

                if (inputan.equalsIgnoreCase(id)) {
                    if (id.charAt(0) == 'D') {
                        tfNama.setText(nama);
                        labelNomor.setText("NIP");
                        tfNomor.setText(nomor);
                        tfAlamat.setText(alamat);
                        tfPinjam.setText(maxPinjam);
                    } else if (id.charAt(0) == 'M') {
                        tfNama.setText(nama);
                        labelNomor.setText("NIM");
                        tfNomor.setText(nomor);
                        tfAlamat.setText(alamat);
                        tfPinjam.setText(maxPinjam);
                    } else if (id.charAt(0) == 'U') {
                        tfNama.setText(nama);
                        labelNomor.setText("NIK");
                        tfNomor.setText(nomor);
                        tfAlamat.setText(alamat);
                        tfPinjam.setText(maxPinjam);
                    }
                    break;
                }
                if (i == peminjam.length - 1) {
                    JOptionPane.showMessageDialog(this, "Maaf, data tidak ditemukan");
                }
                i++;
            }

        } catch (FileNotFoundException ex) {
            JOptionPane.showMessageDialog(this, "Mohon maaf data peminjam masih kosong, mohon mengisi dahulu");
            this.dispose();
        } catch (IOException ex) {
            Logger.getLogger(KelolaDataTransaksiPeminjaman.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(KelolaDataTransaksiPeminjaman.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_buttonCariPeminjamActionPerformed

    private void tfIDKoleksiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfIDKoleksiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfIDKoleksiActionPerformed

    private void tfJudulActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfJudulActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfJudulActionPerformed

    private void buttonCariKoleksiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonCariKoleksiActionPerformed
        try {
            File inFile = new File("C:\\Users\\LENOVO\\Desktop\\Koleksi.dat");
            FileInputStream inFileStream = new FileInputStream(inFile);
            ObjectInputStream inObjectStream = new ObjectInputStream(inFileStream);
            String inputan = tfIDKoleksi.getText();

            Koleksi[] koleksi;
            koleksi = (Koleksi[]) inObjectStream.readObject();
            String id, judul, penerbit, issn, isbn, format, halaman, volume, seri, status;

            int i = 0;
            while (i < koleksi.length) {
                id = koleksi[i].getIdKoleksi();
                judul = koleksi[i].getJudul();
                penerbit = koleksi[i].getPenerbit();
                issn = koleksi[i].getIS();
                volume = String.valueOf(koleksi[i].getVolume());
                seri = String.valueOf(koleksi[i].getSeri());
                status = String.valueOf(koleksi[i].isStatus_pinjam());
                isbn = koleksi[i].getIS();
                format = koleksi[i].getFormat();
                halaman = String.valueOf(koleksi[i].getHalaman());

                if (inputan.equalsIgnoreCase(id)) {
                    if (id.charAt(0) == 'M') {
                        tfJudul.setText(judul);
                        tfPenerbit.setText(penerbit);
                        tfIS.setText(issn);
                        labelVolume.setText("Volume");
                        tfVolume.setText(volume);
                        tfSeri.setEnabled(true);
                        tfSeri.setText(seri);
                        labelSeri.setVisible(true);
                        tfStatus.setText(status);
                    } else if (id.charAt(0) == 'B') {
                        tfJudul.setText(judul);
                        tfPenerbit.setText(penerbit);
                        tfIS.setText(isbn);
                        labelVolume.setText("Hal");
                        tfVolume.setText(halaman);
                        tfSeri.setEnabled(false);
                        tfStatus.setText(status);
                        labelSeri.setVisible(false);
                    } else if (id.charAt(0) == 'D') {
                        tfJudul.setText(judul);
                        tfPenerbit.setText(penerbit);
                        tfIS.setText(isbn);
                        labelVolume.setText("Format");
                        tfVolume.setText(format);
                        tfSeri.setEnabled(false);
                        tfStatus.setText(status);
                        labelSeri.setVisible(false);
                    }
                    break;
                }
                if (i == koleksi.length - 1) {
                    JOptionPane.showMessageDialog(this, "Maaf, data tidak ditemukan");
                }
                i++;
            }
        } catch (FileNotFoundException ex) {
            JOptionPane.showMessageDialog(this, "Mohon maaf data koleksi masih kosong, mohon mengisi dahulu");
            this.dispose();
        } catch (IOException ex) {
            Logger.getLogger(KelolaDataTransaksiPeminjaman.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(KelolaDataTransaksiPeminjaman.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_buttonCariKoleksiActionPerformed

    private void buttonBatalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonBatalActionPerformed
        resetKoleksi();
        resetPeminjam();
        int jumlahData = tabelPesananKoleksi.getRowCount();
        for (int i = 0; i < jumlahData; i++) {
            list.getKoleksi().remove(i);
        }
        tampilDataKoleksi();
    }//GEN-LAST:event_buttonBatalActionPerformed

    private void resetPeminjam() {
        tfIDPeminjam.setText("");
        tfNama.setText("");
        tfNomor.setText("");
        tfAlamat.setText("");
        tfPinjam.setText("");
    }

    private void buttonTambahPesananActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonTambahPesananActionPerformed
        String a;
        a = tfIDKoleksi.getText();
        if (a.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Mohon masukkan ID");
        } else if (tfStatus.getText().equalsIgnoreCase("true")) {
            JOptionPane.showMessageDialog(this, "Mohon maaf, barang sudah dipinjam");
        } else if (tabelPesananKoleksi.getRowCount() == Integer.parseInt(tfPinjam.getText())) {
            JOptionPane.showMessageDialog(this, "Maaf, peminjaman sudah melebihi batas (maks " + tabelPesananKoleksi.getRowCount() + ")");
        } else {
            //ambil data dari textField
            boolean statusBoolean;
            String idKoleksi = tfIDKoleksi.getText();
            String judul = tfJudul.getText();
            String penerbit = tfPenerbit.getText();
            String isbnissn = tfIS.getText();
            String status = tfStatus.getText();
            if (status.equalsIgnoreCase("true")) {
                statusBoolean = true;
            } else {
                statusBoolean = false;
            }

            //start buat objek Koleksi sementara
            Koleksi k = new Koleksi(idKoleksi, judul, penerbit, statusBoolean);
            k.setIS(isbnissn);
            list.getKoleksi().add(k);
            //end Koleksi sementara
            tampilDataKoleksi();
            resetKoleksi();
        }

    }//GEN-LAST:event_buttonTambahPesananActionPerformed

    private void buttonTransaksiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonTransaksiActionPerformed

        if (tfIDPeminjam.getText().isEmpty() || tabelPesananKoleksi.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "Mohon memasukkan ID data terlebih dahulu");
        } else {
            tampilDataTransaksi();
            JOptionPane.showMessageDialog(this, "Transaksi berhasil! Terimakasih telah melakukan peminjaman"
                    + ", nota telah dibuat dalam bentuk file");
            try {
                rancangNota();
            } catch (IOException ex) {
                Logger.getLogger(KelolaDataTransaksiPeminjaman.class.getName()).log(Level.SEVERE, null, ex);
            }
            buttonTransaksi.setEnabled(false);
            buttonBatal.setEnabled(false);
            resetPeminjam();
            resetKoleksi();
            buttonTambahPesanan.setEnabled(false);
        }

    }//GEN-LAST:event_buttonTransaksiActionPerformed
    
    private void rancangNota() throws FileNotFoundException, IOException {
        //buat file Nota.dat
        File outFile = new File("C:\\Users\\LENOVO\\Desktop\\Nota.dat");
        FileOutputStream outFileStream = new FileOutputStream(outFile);
        ObjectOutputStream outObjectStream = new ObjectOutputStream(outFileStream);

        int idTransaksi = generateID;
        String idPeminjam = tfIDKoleksi.getText();
        String nama = tfNama.getText();
        String alamat = tfAlamat.getText();
        int maxPinjam = Integer.parseInt(tfPinjam.getText());

        Koleksi[] koleksiNota = new Koleksi[list.getKoleksi().size()];
        for (int i = 0; i < list.getKoleksi().size(); i++) {
            koleksiNota[i] = list.getKoleksi().get(i);
        }
        Peminjam peminjamNota = new Peminjam(idPeminjam, nama, alamat, maxPinjam);

        Transaksi nota = new Transaksi(idTransaksi, LocalDate.now(), koleksiNota, peminjamNota);

        outObjectStream.writeObject(nota);
        outObjectStream.close();
        
        //buat NOTA versi notepad
        outFile = new File("C:\\Users\\LENOVO\\Desktop\\Nota.txt");
        outFileStream = new FileOutputStream(outFile);
        //outObjectStream = new ObjectOutputStream(outFileStream);
        
        String teks1 = "NOTA";
        String teks2 = "\n------------------------";
        String teks3 = "\nNama Peminjam : " + peminjamNota.getNama();
        String teks4 = "\nAlamat : " + peminjamNota.getAlamat();
        String teks5 = "\nID Transaksi : " + generateID;
        String teks6 = "\nTanggal Pinjam " + LocalDate.now();
        String teks7 = "\nJumlah Koleksi : " + koleksiNota.length;
        String teks8 = "\nDengan Koleksi : \n";
        String teks9 = "";
        for (int i = 0; i < koleksiNota.length; i++) {
            teks9 = teks9 + (i+1) + ".) " + koleksiNota[i].getIdKoleksi().toUpperCase() 
                    + " - " + koleksiNota[i].getJudul() + "\n";
        }
        outFileStream.write(teks1.getBytes());
        outFileStream.write(teks2.getBytes());
        outFileStream.write(teks3.getBytes());
        outFileStream.write(teks4.getBytes());
        outFileStream.write(teks5.getBytes());
        outFileStream.write(teks6.getBytes());
        outFileStream.write(teks7.getBytes());
        outFileStream.write(teks8.getBytes());
        outFileStream.write(teks9.getBytes());
        outFileStream.close();
    }

    private void tampilDataTransaksi() {
        String[] columnNames = {"ID Transaksi", "Peminjam", "Alamat", "Tanggal Pinjam", "Jumlah Pinjam"};
        Object[][] objData = new Object[1][columnNames.length];

        //inisisasi data
        int idTransaksi = generateID;
        String peminjam = tfNama.getText();
        String alamat = tfAlamat.getText();
        int jumlahPinjam = tabelPesananKoleksi.getRowCount();

        Object[] konten = {idTransaksi, peminjam, alamat, LocalDate.now(), jumlahPinjam};
        objData[0] = konten;
        modelTabelTransaksi = new DefaultTableModel(objData, columnNames) {
            @Override
            public boolean isCellEditable(int rowIndex, int colIndex) {
                return false;
            }
        };
        tabelTransaksi.setModel(modelTabelTransaksi);
        tabelTransaksi.setAutoCreateRowSorter(true);
        tabelTransaksi.repaint();
    }

    private void resetKoleksi() {
        tfIDKoleksi.setText("");
        tfJudul.setText("");
        tfPenerbit.setText("");
        tfSeri.setText("");
        tfVolume.setText("");
        tfIS.setText("");
        tfStatus.setText("");
    }

    private void tampilDataKoleksi() {

        //set format tabel
        String[] columnNames = {"ID", "Judul", "Penerbit", "ISBN/SN", "Status"};
        Object[][] objData = new Object[list.getKoleksi().size()][columnNames.length]; //maks pinjam tergantung objek Peminjam
        int i = 0;

        for (Koleksi koleksi : list.getKoleksi()) {
            Object[] teks = {koleksi.getIdKoleksi(), koleksi.getJudul(), koleksi.getPenerbit(), koleksi.getIStemp(), koleksi.isStatus_pinjam()};
            objData[i] = teks;
            i++;
        }

        //set Model Tabel
        modelTabel = new DefaultTableModel(objData, columnNames) {
            @Override
            public boolean isCellEditable(int rowIndex, int colIndex) {
                return false;

            }
        };
        tabelPesananKoleksi.setModel(modelTabel);
        tabelPesananKoleksi.setAutoCreateRowSorter(true);
        tabelPesananKoleksi.repaint();
    }

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(KelolaDataTransaksiPeminjaman.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(KelolaDataTransaksiPeminjaman.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(KelolaDataTransaksiPeminjaman.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(KelolaDataTransaksiPeminjaman.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                KelolaDataTransaksiPeminjaman dialog = new KelolaDataTransaksiPeminjaman(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton buttonBatal;
    private javax.swing.JButton buttonCariKoleksi;
    private javax.swing.JButton buttonCariPeminjam;
    private javax.swing.JButton buttonTambahPesanan;
    private javax.swing.JButton buttonTransaksi;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel labelNomor;
    private javax.swing.JLabel labelSeri;
    private javax.swing.JLabel labelVolume;
    private javax.swing.JTable tabelPesananKoleksi;
    private javax.swing.JTable tabelTransaksi;
    private javax.swing.JTextField tfAlamat;
    private javax.swing.JTextField tfIDKoleksi;
    private javax.swing.JTextField tfIDPeminjam;
    private javax.swing.JTextField tfIS;
    private javax.swing.JTextField tfJudul;
    private javax.swing.JTextField tfNama;
    private javax.swing.JTextField tfNomor;
    private javax.swing.JTextField tfPenerbit;
    private javax.swing.JTextField tfPinjam;
    private javax.swing.JTextField tfSeri;
    private javax.swing.JTextField tfStatus;
    private javax.swing.JTextField tfVolume;
    // End of variables declaration//GEN-END:variables
    DefaultTableModel modelTabel, modelTabelTransaksi;

}
