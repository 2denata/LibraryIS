package Perpustakaan;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;

public class TestDAT {

    public static void main(String[] args) throws FileNotFoundException, IOException, ClassNotFoundException {
        //setup file and stream
        File inFile = new File("C:\\Users\\LENOVO\\Desktop\\Koleksi.dat");

        FileInputStream inFileStream = new FileInputStream(inFile);

        ObjectInputStream inObjectStream = new ObjectInputStream(inFileStream);

        //read the Person objects from a file
        Koleksi[] koleksi = new Koleksi[3];

        koleksi = (Koleksi[]) inObjectStream.readObject();
        for (int i = 0; i < koleksi.length; i++) {
            System.out.println(koleksi[i].getIdKoleksi() + "     "
                    + koleksi[i].getJudul() + "     "
                    + koleksi[i].getPenerbit());
        }

        //input done, so close the stream
        inObjectStream.close();

        inFile = new File("C:\\Users\\LENOVO\\Desktop\\Peminjam.dat");

        inFileStream = new FileInputStream(inFile);

        inObjectStream = new ObjectInputStream(inFileStream);

        //read the Person objects from a file
        Peminjam[] peminjam = new Peminjam[3];

        peminjam = (Peminjam[]) inObjectStream.readObject();
        for (int i = 0; i < peminjam.length; i++) {
            System.out.println(peminjam[i].getIdPeminjam() + "     "
                    + peminjam[i].getNomor() + "     "
                    + peminjam[i].getAlamat());
        }

        System.out.println("");
        System.out.println("");
        //input done, so close the stream
        inObjectStream.close();

        inObjectStream.close();

         inFile = new File("C:\\Users\\LENOVO\\Desktop\\Nota.dat");

         inFileStream = new FileInputStream(inFile);

         inObjectStream = new ObjectInputStream(inFileStream);

        //read the Person objects from a file
        Transaksi nota = (Transaksi) inObjectStream.readUnshared();

        System.out.println("NOTA");
        System.out.println("-------------------------------------------");
        System.out.println("ID Transaksi : " + nota.getIdTransaksi() + "     "
                + "\nTanggal Pinjam : " + nota.getTglPinjam() + "     "
                + "\nDengan Koleksi : " );
        for (int i = 0; i < nota.getKoleksi().length; i++) {
            System.out.println((i+1)+".) " + nota.getKoleksi()[i].getIdKoleksi() + " - " + nota.getKoleksi()[i].getJudul());
        }

        //input done, so close the stream
        inObjectStream.close();

    }
}
